from django.apps import AppConfig


class BagConfig(AppConfig):
    name = 'bag'
